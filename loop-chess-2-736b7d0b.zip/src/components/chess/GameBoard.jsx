
import React from 'react';
import { motion } from 'framer-motion';
import ChessPiece from './ChessPiece';
import { getSquareType, getSquareLabel } from './GameEngine';
import { HIDDEN_VALLEY_SQUARES } from './PieceMovement';

const BOARD_SIZE = 20;

const TERRITORY_COLORS = {
  0: { light: 'bg-blue-300', dark: 'bg-blue-700' },
  1: { light: 'bg-red-300', dark: 'bg-red-700' },
  2: { light: 'bg-green-300', dark: 'bg-green-700' },
  3: { light: 'bg-purple-300', dark: 'bg-purple-700' }
};

const NEUTRAL_COLORS = {
  light: 'bg-white',
  dark: 'bg-slate-900'
};

export default function GameBoard({ 
  boardState, 
  onSquareClick, 
  selectedSquare,
  validMoves,
  viewPerspective,
  territories,
  playerColors,
  hiddenValleyTracking,
  lastMove
}) {
  const getSquareColor = (row, col, type, territory) => {
    if (type === 'mountain') return 'bg-amber-800';
    if (type === 'ocean') return 'bg-slate-950'; // Dark navy blue
    
    const isLight = (row + col) % 2 === 0;
    
    // If playerColors are provided, we'll use inline styles, so return empty string for class
    if (territory !== null && territory !== undefined && playerColors) {
      return '';  // Will use inline style instead
    }
    
    // Fallback to default TERRITORY_COLORS if playerColors not provided or not applicable
    if (territory !== null && territory !== undefined) {
      const colors = TERRITORY_COLORS[territory];
      return isLight ? colors.light : colors.dark;
    }
    
    // Neutral squares
    return isLight ? NEUTRAL_COLORS.light : NEUTRAL_COLORS.dark;
  };

  const getSquareStyle = (row, col, type, territory) => {
    if (territory !== null && territory !== undefined && playerColors) {
      const colors = playerColors[territory];
      const isLight = (row + col) % 2 === 0;
      return { backgroundColor: isLight ? colors.light : colors.dark };
    }
    return {};
  };

  const isValidMove = (row, col) => {
    return validMoves?.some(move => move.row === row && move.col === col);
  };

  const getPieceAt = (row, col) => {
    return boardState?.[`${row},${col}`];
  };

  const isHiddenValley = (row, col) => {
    return HIDDEN_VALLEY_SQUARES.includes(`${row},${col}`);
  };

  const getHiddenValleyGlow = (row, col) => {
    const square = `${row},${col}`;
    for (const [key, data] of Object.entries(hiddenValleyTracking)) {
      if (data.squares.includes(square)) {
        return { turns: data.turns, valleyName: data.valleyName };
      }
    }
    return null;
  };

  const isLastMoveSquare = (row, col) => {
    if (!lastMove) return false;
    return (lastMove.from.row === row && lastMove.from.col === col) ||
           (lastMove.to.row === row && lastMove.to.col === col);
  };

  const rotateBoard = () => {
    if (viewPerspective === 0) return 0;
    if (viewPerspective === 1) return 270;
    if (viewPerspective === 2) return 180;
    if (viewPerspective === 3) return 90;
    return 0;
  };

  return (
    <div className="flex items-center justify-center p-8 relative">
      {/* Row numbers - LEFT SIDE */}
      <div 
        className="absolute left-0 top-0 h-full flex flex-col justify-center ml-2"
        style={{
          transform: `rotate(${rotateBoard()}deg)`,
          transition: 'transform 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        {Array.from({ length: BOARD_SIZE }).map((_, row) => (
          <div key={row} className="h-8 flex items-center justify-center text-xs text-gray-500 font-mono">
            {row + 1}
          </div>
        ))}
      </div>
      
      <motion.div 
        className="relative bg-stone-800 p-4 rounded-2xl shadow-2xl"
        style={{
          transform: `rotate(${rotateBoard()}deg)`,
          transition: 'transform 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        {/* Column letters - TOP */}
        <div className="flex gap-0.5 mb-1 ml-0.5">
          {Array.from({ length: BOARD_SIZE }).map((_, col) => (
            <div key={col} className="w-8 flex items-center justify-center text-xs text-gray-400 font-mono">
              {String.fromCharCode(97 + col)}
            </div>
          ))}
        </div>
        
        <div className="grid gap-0.5 bg-stone-900 p-0.5 rounded-xl">
          {Array.from({ length: BOARD_SIZE }).map((_, row) => (
            <div key={row} className="flex gap-0.5">
              {Array.from({ length: BOARD_SIZE }).map((_, col) => {
                const squareType = getSquareType(row, col);
                const piece = getPieceAt(row, col);
                const isSelected = selectedSquare?.row === row && selectedSquare?.col === col;
                const isValid = isValidMove(row, col);
                const territory = territories?.[`${row},${col}`];
                const squareLabel = getSquareLabel(row, col);
                const hiddenValley = isHiddenValley(row, col);
                const valleyGlow = getHiddenValleyGlow(row, col);
                const isLastMove = isLastMoveSquare(row, col);
                
                return (
                  <motion.div
                    key={`${row}-${col}`}
                    className={`
                      w-8 h-8 relative cursor-pointer transition-all duration-200
                      ${getSquareColor(row, col, squareType, territory)}
                      ${isSelected ? 'ring-4 ring-yellow-400 ring-inset' : ''}
                      ${isLastMove ? 'ring-2 ring-blue-400 ring-inset shadow-lg' : ''}
                      ${squareType === 'playable' ? 'hover:opacity-80' : ''}
                      ${valleyGlow ? 'ring-2 ring-purple-500 animate-pulse' : ''}
                    `}
                    style={getSquareStyle(row, col, squareType, territory)}
                    onClick={() => squareType === 'playable' && onSquareClick(row, col)}
                    whileHover={squareType === 'playable' ? { scale: 1.05 } : {}}
                    title={squareType === 'playable' ? squareLabel : ''}
                  >
                    {squareType === 'mountain' && (
                      <div className="absolute inset-0 flex items-center justify-center text-amber-950 text-lg font-bold">
                        {hiddenValley ? '🕳️' : '⛰'}
                      </div>
                    )}
                    {squareType === 'ocean' && (
                      <div className="absolute inset-0 flex items-center justify-center text-blue-600 text-xs opacity-40">
                        🌊
                      </div>
                    )}
                    {piece && squareType === 'playable' && (
                      <ChessPiece 
                        piece={piece} 
                        perspective={viewPerspective}
                        playerColors={playerColors}
                      />
                    )}
                    {isValid && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute inset-0 flex items-center justify-center"
                      >
                        <div className={`w-3 h-3 rounded-full ${
                          piece ? 'ring-2 ring-red-500' : 'bg-green-500 opacity-60'
                        }`} />
                      </motion.div>
                    )}
                    {valleyGlow && (
                      <div className="absolute top-0 right-0 text-xs text-purple-600 font-bold bg-white rounded-full w-4 h-4 flex items-center justify-center">
                        {valleyGlow.turns}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
