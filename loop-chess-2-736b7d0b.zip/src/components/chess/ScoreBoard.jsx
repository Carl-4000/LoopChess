import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Crown, Skull, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const PLAYER_INFO = [
  { name: 'Azure', color: 'text-blue-500', bg: 'bg-blue-50', border: 'border-blue-200', progressBg: 'bg-blue-500' },
  { name: 'Crimson', color: 'text-red-500', bg: 'bg-red-50', border: 'border-red-200', progressBg: 'bg-red-500' },
  { name: 'Emerald', color: 'text-green-500', bg: 'bg-green-50', border: 'border-green-200', progressBg: 'bg-green-500' },
  { name: 'Amethyst', color: 'text-purple-500', bg: 'bg-purple-50', border: 'border-purple-200', progressBg: 'bg-purple-500' }
];

export default function ScoreBoard({ 
  territoryPercentages, 
  currentTurn, 
  eliminatedPlayers, 
  gameStatus,
  playerColors
}) {
  const sortedPlayers = [0, 1, 2, 3].sort((a, b) => 
    (territoryPercentages[b] || 0) - (territoryPercentages[a] || 0)
  );
  const winner = gameStatus === 'completed' ? sortedPlayers[0] : null;
  
  const getPlayerColor = (player) => {
    if (playerColors) {
      return playerColors[player].main;
    }
    return PLAYER_INFO[player].color;
  };
  
  const getPlayerBg = (player) => {
    if (playerColors) {
      return `${playerColors[player].light}33`;
    }
    return PLAYER_INFO[player].bg;
  };
  
  const getPlayerName = (player) => {
    if (playerColors) {
      return playerColors[player].name;
    }
    return PLAYER_INFO[player].name;
  };

  return (
    <Card className="shadow-xl border-2">
      <CardHeader className="border-b bg-gradient-to-r from-slate-50 to-slate-100">
        <CardTitle className="flex items-center gap-3 text-2xl">
          <Target className="w-6 h-6 text-yellow-500" />
          Territory Control
        </CardTitle>
        <p className="text-sm text-gray-500 mt-1">First to 75% wins!</p>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {sortedPlayers.map((player, index) => {
            const info = PLAYER_INFO[player];
            const isEliminated = eliminatedPlayers.includes(player);
            const isCurrentTurn = currentTurn === player && !isEliminated;
            const isWinner = winner === player;
            const territoryPct = territoryPercentages[player] || 0;
            
            const playerMainColor = getPlayerColor(player);
            const playerLightBg = getPlayerBg(player);
            
            return (
              <motion.div
                key={player}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`
                  p-4 rounded-xl border-2 transition-all duration-300
                  ${isCurrentTurn ? 'ring-4 ring-yellow-400 ring-opacity-50' : ''}
                  ${isEliminated ? 'opacity-40' : ''}
                  ${!playerColors ? `${info.bg} ${info.border}` : ''}
                `}
                style={{
                  backgroundColor: playerColors ? playerLightBg : undefined,
                  borderColor: playerColors ? playerMainColor : undefined
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div 
                      className={`text-3xl font-bold ${typeof playerMainColor === 'string' && !playerMainColor.startsWith('#') ? playerMainColor : ''}`}
                      style={{ color: typeof playerMainColor === 'string' && playerMainColor.startsWith('#') ? playerMainColor : undefined }}
                    >
                      #{index + 1}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span 
                          className={`text-lg font-semibold ${typeof playerMainColor === 'string' && !playerMainColor.startsWith('#') ? playerMainColor : ''}`}
                          style={{ color: typeof playerMainColor === 'string' && playerMainColor.startsWith('#') ? playerMainColor : undefined }}
                        >
                          Player {player + 1}
                        </span>
                        <span className="text-sm text-gray-500">
                          ({getPlayerName(player)})
                        </span>
                        {isWinner && (
                          <Crown className="w-5 h-5 text-yellow-500" />
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge 
                          variant="outline" 
                          className={typeof playerMainColor === 'string' && !playerMainColor.startsWith('#') ? playerMainColor : ''}
                          style={{ color: typeof playerMainColor === 'string' && playerMainColor.startsWith('#') ? playerMainColor : undefined }}
                        >
                          {territoryPct.toFixed(1)}% Territory
                        </Badge>
                        {isEliminated && (
                          <Badge variant="destructive" className="flex items-center gap-1">
                            <Skull className="w-3 h-3" />
                            King Captured
                          </Badge>
                        )}
                        {isCurrentTurn && (
                          <Badge className="bg-yellow-400 text-yellow-900">
                            Current Turn
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                    <span>Territory Progress</span>
                    <span>{territoryPct.toFixed(1)}% / 75%</span>
                  </div>
                  <Progress 
                    value={territoryPct} 
                    max={100}
                    className="h-3"
                    indicatorClassName={!playerColors ? info.progressBg : undefined}
                    style={{
                      '--progress-background': playerColors ? playerMainColor : undefined
                    }}
                  />
                  {territoryPct >= 75 && (
                    <div className="mt-2 text-center">
                      <Badge className="bg-yellow-500 text-yellow-900 font-bold">
                        <Trophy className="w-3 h-3 mr-1" />
                        VICTORY!
                      </Badge>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}