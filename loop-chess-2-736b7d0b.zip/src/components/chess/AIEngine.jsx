import { getValidMoves } from './PieceMovement';
import { makeMove, isInCheck } from './GameEngine';
import { HIDDEN_VALLEY_PAIRS } from './PieceMovement';

const PIECE_VALUES = {
  pawn: 1,
  knight: 3,
  bishop: 4,
  rook: 5,
  queen: 9,
  king: 1000
};

// Cache for frequently calculated values
const cache = {
  defenseMap: new Map(),
  activityMap: new Map(),
  undefendedPieces: new Map()
};

// Clear cache when needed
const clearCache = () => {
  cache.defenseMap.clear();
  cache.activityMap.clear();
  cache.undefendedPieces.clear();
};

// Optimized square defense check with caching
const isSquareDefended = (board, row, col, player) => {
  const cacheKey = `${row},${col},${player}`;
  if (cache.defenseMap.has(cacheKey)) {
    return cache.defenseMap.get(cacheKey);
  }
  
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.alive) {
      const [r, c] = key.split(',').map(Number);
      const moves = getValidMoves(board, r, c, piece, null);
      if (moves.some(m => m.row === row && m.col === col)) {
        cache.defenseMap.set(cacheKey, true);
        return true;
      }
    }
  }
  
  cache.defenseMap.set(cacheKey, false);
  return false;
};

// Count how many pieces defend a square
const countDefenders = (board, row, col, player) => {
  let count = 0;
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.alive) {
      const [r, c] = key.split(',').map(Number);
      const moves = getValidMoves(board, r, c, piece, null);
      if (moves.some(m => m.row === row && m.col === col)) {
        count++;
      }
    }
  }
  return count;
};

// Find all undefended pieces for a player
const findUndefendedPieces = (board, player) => {
  const cacheKey = `undefended-${player}`;
  if (cache.undefendedPieces.has(cacheKey)) {
    return cache.undefendedPieces.get(cacheKey);
  }
  
  const undefended = [];
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.alive && piece.type !== 'king') {
      const [row, col] = key.split(',').map(Number);
      if (!isSquareDefended(board, row, col, player)) {
        undefended.push({ row, col, piece, value: PIECE_VALUES[piece.type] });
      }
    }
  }
  
  cache.undefendedPieces.set(cacheKey, undefended);
  return undefended;
};

// Check if king has been castled and has good protection
const evaluateKingCastledAndProtected = (board, player) => {
  let kingPos = null;
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.type === 'king' && piece.alive) {
      kingPos = { key, hasMoved: piece.hasMoved };
      break;
    }
  }
  
  if (!kingPos) return 0;
  if (!kingPos.hasMoved) return -500; // Penalize not castling
  
  const [kingRow, kingCol] = kingPos.key.split(',').map(Number);
  let score = 500; // Bonus for castling
  
  // Check for ideal pawn shield (3 pawns)
  const neighbors = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1]
  ];
  
  let pawnShield = 0;
  let knightProtection = 0;
  let rookProtection = 0;
  let bishopProtection = 0;
  
  for (const [dr, dc] of neighbors) {
    const piece = board[`${kingRow + dr},${kingCol + dc}`];
    if (piece && piece.player === player && piece.alive) {
      if (piece.type === 'pawn') pawnShield++;
      if (piece.type === 'knight') knightProtection++;
      if (piece.type === 'rook') rookProtection++;
      if (piece.type === 'bishop') bishopProtection++;
    }
  }
  
  // Ideal: 3 pawns + knight/rook/bishop
  score += Math.min(pawnShield, 3) * 200;
  score += knightProtection * 150;
  score += rookProtection * 150;
  score += bishopProtection * 150;
  
  return score;
};

// Evaluate pawn chains moving toward Hidden Valleys
const evaluatePawnChainToValley = (board, player) => {
  let score = 0;
  const pawns = [];
  
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.type === 'pawn' && piece.alive) {
      const [row, col] = key.split(',').map(Number);
      pawns.push({ row, col, key, defended: isSquareDefended(board, row, col, player) });
    }
  }
  
  // Bonus for defended pawns
  const defendedPawns = pawns.filter(p => p.defended);
  score += defendedPawns.length * 80;
  
  // Bonus for pawns moving toward valleys in groups
  for (const valley of HIDDEN_VALLEY_PAIRS) {
    let pawnsNearValley = 0;
    let defendedNearValley = 0;
    
    for (const pawn of pawns) {
      for (const valleySquare of valley.squares) {
        const [vRow, vCol] = valleySquare.split(',').map(Number);
        const dist = Math.abs(pawn.row - vRow) + Math.abs(pawn.col - vCol);
        
        if (dist <= 4) {
          pawnsNearValley++;
          if (pawn.defended) defendedNearValley++;
          score += (5 - dist) * 15;
        }
      }
    }
    
    // Bonus for having 5+ pawns near valley
    if (pawnsNearValley >= 5) score += 300;
    if (defendedNearValley >= 3) score += 200;
  }
  
  return score;
};

// Evaluate overall army coordination
const evaluateArmyCoordination = (board, player) => {
  let score = 0;
  const pieces = [];
  
  let kingPos = null;
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.type === 'king' && piece.alive) {
      kingPos = key;
      break;
    }
  }
  
  if (!kingPos) return 0;
  const [kingRow, kingCol] = kingPos.split(',').map(Number);
  
  // Find closest Hidden Valley to king
  let closestValleyDist = 999;
  let closestValley = null;
  
  for (const valley of HIDDEN_VALLEY_PAIRS) {
    for (const valleySquare of valley.squares) {
      const [vRow, vCol] = valleySquare.split(',').map(Number);
      const dist = Math.abs(kingRow - vRow) + Math.abs(kingCol - vCol);
      if (dist < closestValleyDist) {
        closestValleyDist = dist;
        closestValley = valley;
      }
    }
  }
  
  // Bonus for pieces positioned between king and valley
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.alive && piece.type !== 'king') {
      const [row, col] = key.split(',').map(Number);
      const distToKing = Math.abs(row - kingRow) + Math.abs(col - kingCol);
      
      if (closestValley) {
        let minDistToValley = 999;
        for (const valleySquare of closestValley.squares) {
          const [vRow, vCol] = valleySquare.split(',').map(Number);
          const dist = Math.abs(row - vRow) + Math.abs(col - vCol);
          minDistToValley = Math.min(minDistToValley, dist);
        }
        
        // Pieces halfway between king and valley get bonus
        if (distToKing >= 3 && minDistToValley >= 3 && distToKing <= 8 && minDistToValley <= 8) {
          score += 60;
          if (isSquareDefended(board, row, col, player)) score += 40;
        }
      }
    }
  }
  
  return score;
};

// Optimized king safety evaluation
const evaluateKingSafety = (board, player) => {
  let kingPos = null;
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.type === 'king' && piece.alive) {
      kingPos = key;
      break;
    }
  }
  
  if (!kingPos) return 0;
  
  const [kingRow, kingCol] = kingPos.split(',').map(Number);
  let safety = 0;
  
  // Edge proximity
  const distFromEdge = Math.min(
    kingRow, 19 - kingRow,
    kingCol, 19 - kingCol
  );
  safety += (10 - distFromEdge) * 20;
  
  // Protective pieces
  const protectors = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1]
  ];
  
  let pawnShield = 0;
  let minorPieceProtection = 0;
  
  for (const [dr, dc] of protectors) {
    const piece = board[`${kingRow + dr},${kingCol + dc}`];
    if (piece && piece.player === player && piece.alive) {
      if (piece.type === 'pawn') pawnShield++;
      else if (piece.type === 'knight' || piece.type === 'bishop') minorPieceProtection++;
    }
  }
  
  return safety + pawnShield * 50 + minorPieceProtection * 30;
};

// Optimized piece activity evaluation with caching
const evaluatePieceActivity = (board, row, col, piece) => {
  if (!piece.alive) return 0;
  
  const cacheKey = `${row},${col}`;
  if (cache.activityMap.has(cacheKey)) {
    return cache.activityMap.get(cacheKey);
  }
  
  const moves = getValidMoves(board, row, col, piece, null);
  const activity = moves.length;
  cache.activityMap.set(cacheKey, activity);
  return activity;
};

// Find least active piece (excluding king defenders)
const findLeastActivePiece = (board, player) => {
  let kingPos = null;
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.type === 'king' && piece.alive) {
      kingPos = key;
      break;
    }
  }
  
  if (!kingPos) return null;
  
  const [kingRow, kingCol] = kingPos.split(',').map(Number);
  
  let leastActive = null;
  let minActivity = 999;
  
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player !== player || !piece.alive || piece.type === 'king') continue;
    
    const [row, col] = key.split(',').map(Number);
    
    // Skip king defenders
    const distToKing = Math.max(Math.abs(row - kingRow), Math.abs(col - kingCol));
    if (distToKing <= 1) continue;
    
    const activity = evaluatePieceActivity(board, row, col, piece);
    if (activity < minActivity) {
      minActivity = activity;
      leastActive = { row, col, piece, key, activity };
    }
  }
  
  return leastActive;
};

// Optimized Hidden Valley progress evaluation
const evaluateHiddenValleyProgress = (board, player) => {
  let score = 0;
  
  for (const valley of HIDDEN_VALLEY_PAIRS) {
    let pawnsInValley = 0;
    for (const square of valley.squares) {
      const piece = board[square];
      if (piece && piece.type === 'pawn' && piece.owner === player && piece.alive) {
        pawnsInValley++;
      }
    }
    
    if (pawnsInValley === 2) {
      score += 500;
    } else if (pawnsInValley === 1) {
      score += 100;
    }
    
    // Bonus for pawns near valleys
    for (const [key, piece] of Object.entries(board)) {
      if (piece.player === player && piece.type === 'pawn' && piece.alive) {
        const [row, col] = key.split(',').map(Number);
        
        for (const valleySquare of valley.squares) {
          const [vRow, vCol] = valleySquare.split(',').map(Number);
          const dist = Math.abs(row - vRow) + Math.abs(col - vCol);
          if (dist <= 3) {
            score += (4 - dist) * 10;
          }
        }
      }
    }
  }
  
  return score;
};

// Optimized opening evaluation
const evaluateOpening = (board, player, moveNumber) => {
  if (moveNumber > 12) return 0;
  
  let pawnsMoved = 0;
  let knightsDeveloped = 0;
  let bishopsDeveloped = 0;
  let kingCastled = false;
  
  for (const piece of Object.values(board)) {
    if (piece.player !== player || !piece.alive) continue;
    
    if (piece.hasMoved) {
      if (piece.type === 'pawn') pawnsMoved++;
      else if (piece.type === 'knight') knightsDeveloped++;
      else if (piece.type === 'bishop') bishopsDeveloped++;
      else if (piece.type === 'king') kingCastled = true;
    }
  }
  
  let score = Math.min(pawnsMoved, 2) * 40;
  score += knightsDeveloped * 100;
  score += bishopsDeveloped * 100;
  score += kingCastled ? 200 : 0;
  
  if (moveNumber > 8) {
    if (pawnsMoved < 2) score -= 100;
    if (knightsDeveloped < 2) score -= 150;
    if (bishopsDeveloped < 2) score -= 150;
    if (!kingCastled) score -= 200;
  }
  
  return score;
};

// Check if can block check
const canBlockCheck = (board, player) => {
  if (!isInCheck(board, player)) return null;
  
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.alive) {
      const [row, col] = key.split(',').map(Number);
      const moves = getValidMoves(board, row, col, piece, null);
      
      for (const move of moves) {
        const simulatedBoard = { ...board };
        simulatedBoard[`${move.row},${move.col}`] = piece;
        delete simulatedBoard[key];
        
        if (!isInCheck(simulatedBoard, player)) {
          return { from: { row, col }, to: move, isBlocking: true };
        }
      }
    }
  }
  
  return null;
};

export const makeAIMove = (board, player, eliminatedPlayers, territories, thinkingTime = 1000, lastMove = null) => {
  // Clear caches for new move evaluation
  clearCache();
  
  const moveNumber = Object.values(board).filter(p => p.player === player && p.hasMoved).length;
  
  // Block check if in check
  if (isInCheck(board, player)) {
    const blockMove = canBlockCheck(board, player);
    if (blockMove) {
      return { move: blockMove, thinkingTime };
    }
  }
  
  // Get all pieces and find undefended ones
  const playerPieces = [];
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.alive) {
      const [row, col] = key.split(',').map(Number);
      playerPieces.push({ row, col, piece, key });
    }
  }
  
  if (playerPieces.length === 0) return null;
  
  const undefendedPieces = findUndefendedPieces(board, player);
  const leastActive = findLeastActivePiece(board, player);
  const allMoves = [];
  
  // Evaluate all moves
  for (const { row, col, piece, key } of playerPieces) {
    const validMoves = getValidMoves(board, row, col, piece, lastMove);
    const isCurrentlyDefended = isSquareDefended(board, row, col, player);
    
    for (const move of validMoves) {
      const targetPiece = board[`${move.row},${move.col}`];
      let score = 0;
      
      const { board: simBoard } = makeMove(board, row, col, move.row, move.col, lastMove);
      
      // Don't move into check
      if (isInCheck(simBoard, player)) {
        score -= 10000;
      }
      
      // DEFENSIVE PRIORITY: Don't leave pieces undefended
      const willBeDefended = isSquareDefended(simBoard, move.row, move.col, player);
      if (!willBeDefended) {
        score -= PIECE_VALUES[piece.type] * 150; // Heavy penalty for leaving piece undefended
      } else {
        score += 100; // Bonus for landing on defended square
      }
      
      // Bonus for defending currently undefended pieces
      for (const undefPiece of undefendedPieces) {
        const moves = getValidMoves(simBoard, move.row, move.col, piece, null);
        if (moves.some(m => m.row === undefPiece.row && m.col === undefPiece.col)) {
          score += undefPiece.value * 100; // Big bonus for defending undefended pieces
        }
      }
      
      // Capture enemy kings
      if (targetPiece && targetPiece.type === 'king' && targetPiece.alive) {
        score += 100000;
      }
      
      // Material exchanges (only if defended or good trade)
      if (targetPiece && targetPiece.alive) {
        const captureValue = PIECE_VALUES[targetPiece.type];
        const attackerValue = PIECE_VALUES[piece.type];
        
        const wouldBeRecaptured = isSquareDefended(simBoard, move.row, move.col, targetPiece.owner);
        
        if (wouldBeRecaptured) {
          const tradeValue = captureValue - attackerValue;
          if (tradeValue >= 0 && willBeDefended) {
            score += tradeValue * 120; // Only trade if we'll be defended
          } else {
            score += tradeValue * 300; // Heavy penalty for bad trades
          }
        } else {
          score += captureValue * 200;
        }
        
        // Bonus for capturing from checked armies
        if (isInCheck(board, targetPiece.player)) {
          score += captureValue * 250;
        }
      }
      
      // Clean board - capture dead pieces
      if (targetPiece && !targetPiece.alive) {
        score += 50;
      }
      
      // Check threats
      for (let opp = 0; opp < 4; opp++) {
        if (opp !== player && !eliminatedPlayers.includes(opp) && isInCheck(simBoard, opp)) {
          score += 400;
        }
      }
      
      // STRATEGIC PRIORITIES:
      // 1. Castle king early and protect it
      score += evaluateKingCastledAndProtected(simBoard, player) * 2;
      
      if (piece.type === 'king' && !move.isCastling && moveNumber < 15) {
        score -= 800; // Strong penalty for moving king instead of castling
      }
      if (move.isCastling) score += 600; // Big bonus for castling
      
      // 2. Create defended pawn chains toward valleys
      score += evaluatePawnChainToValley(simBoard, player) * 1.5;
      
      // 3. Position army between king and valley
      score += evaluateArmyCoordination(simBoard, player);
      
      // Opening development
      if (moveNumber <= 12) {
        score += evaluateOpening(simBoard, player, moveNumber);
        
        if ((piece.type === 'knight' || piece.type === 'bishop') && !piece.hasMoved) {
          score += 120;
        }
        
        if (piece.type === 'pawn' && !piece.hasMoved) {
          const pawnsMoved = Object.values(board).filter(p => 
            p.player === player && p.type === 'pawn' && p.hasMoved
          ).length;
          if (pawnsMoved < 2) score += 100;
        }
      }
      
      // Activate least active pieces
      if (leastActive && key === leastActive.key) {
        const newActivity = getValidMoves(simBoard, move.row, move.col, piece, null).length;
        score += (newActivity - leastActive.activity) * 80 + 150;
      }
      
      // Hidden Valley promotion
      score += evaluateHiddenValleyProgress(simBoard, player) * 2;
      
      // King safety
      score += evaluateKingSafety(simBoard, player);
      
      // Center control (minor bonus)
      const centerDist = Math.abs(move.row - 10) + Math.abs(move.col - 10);
      score += (20 - centerDist) * 2;
      
      // Small randomness
      score += Math.random() * 5;
      
      allMoves.push({ from: { row, col }, to: move, score });
    }
  }
  
  if (allMoves.length === 0) return null;
  
  // Sort and select
  allMoves.sort((a, b) => b.score - a.score);
  
  const thinkingDepth = Math.max(1, Math.min(10, Math.floor(thinkingTime / 1000)));
  const topMoves = allMoves.slice(0, thinkingDepth);
  
  // Weighted selection
  const weights = topMoves.map((_, i) => Math.pow(2, topMoves.length - i));
  const totalWeight = weights.reduce((a, b) => a + b, 0);
  let random = Math.random() * totalWeight;
  
  for (let i = 0; i < topMoves.length; i++) {
    random -= weights[i];
    if (random <= 0) {
      return { move: topMoves[i], thinkingTime };
    }
  }
  
  return { move: topMoves[0], thinkingTime };
};