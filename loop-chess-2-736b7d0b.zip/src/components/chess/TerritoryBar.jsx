import React from 'react';
import { motion } from 'framer-motion';
import { Flag } from 'lucide-react';

const PLAYER_INFO = [
  { name: 'Azure', color: 'bg-blue-500' },
  { name: 'Crimson', color: 'bg-red-500' },
  { name: 'Emerald', color: 'bg-green-500' },
  { name: 'Amethyst', color: 'bg-purple-500' }
];

export default function TerritoryBar({ territoryPercentages, playerColors }) {
  // Sort players by territory percentage for display
  const sortedPlayers = [0, 1, 2, 3]
    .map(p => ({ player: p, pct: territoryPercentages[p] || 0 }))
    .sort((a, b) => b.pct - a.pct);
  
  const totalClaimed = sortedPlayers.reduce((sum, p) => sum + p.pct, 0);
  const unclaimed = Math.max(0, 100 - totalClaimed);
  
  const getPlayerColor = (player) => {
    if (playerColors && playerColors[player]) {
      return playerColors[player].main;
    }
    return PLAYER_INFO[player].color.replace('bg-', '').replace('-500', '');
  };
  
  const getPlayerName = (player) => {
    if (playerColors && playerColors[player]) {
      return playerColors[player].name;
    }
    return PLAYER_INFO[player].name;
  };
  
  return (
    <div className="w-full bg-white rounded-xl shadow-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold text-gray-900">Territory Control</h3>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Flag className="w-4 h-4" />
          <span>Victory at 75%</span>
        </div>
      </div>
      
      <div className="relative">
        {/* Main progress bar */}
        <div className="h-12 bg-gray-200 rounded-lg overflow-hidden flex relative">
          {sortedPlayers.map(({ player, pct }) => {
            if (pct === 0) return null;
            return (
              <motion.div
                key={player}
                className="flex items-center justify-center text-white font-bold text-sm"
                style={{ 
                  width: `${pct}%`,
                  backgroundColor: getPlayerColor(player)
                }}
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.5 }}
              >
                {pct >= 8 && (
                  <span>P{player + 1}: {pct.toFixed(1)}%</span>
                )}
              </motion.div>
            );
          })}
          
          {unclaimed > 0 && (
            <motion.div
              className="bg-gray-400 flex items-center justify-center text-gray-700 font-medium text-sm"
              style={{ width: `${unclaimed}%` }}
              initial={{ width: 0 }}
              animate={{ width: `${unclaimed}%` }}
              transition={{ duration: 0.5 }}
            >
              {unclaimed >= 8 && (
                <span>Unclaimed: {unclaimed.toFixed(1)}%</span>
              )}
            </motion.div>
          )}
          
          {/* 75% victory marker */}
          <div 
            className="absolute top-0 bottom-0 w-1 bg-yellow-500 z-10"
            style={{ left: '75%' }}
          >
            <div className="absolute -top-1 left-1/2 -translate-x-1/2">
              <Flag className="w-4 h-4 text-yellow-500" fill="currentColor" />
            </div>
          </div>
        </div>
        
        {/* Legend below */}
        <div className="flex flex-wrap gap-4 mt-4 justify-center">
          {sortedPlayers.map(({ player, pct }) => (
            <div key={player} className="flex items-center gap-2">
              <div 
                className="w-4 h-4 rounded" 
                style={{ backgroundColor: getPlayerColor(player) }}
              />
              <span className="text-sm font-medium text-gray-700">
                P{player + 1} {getPlayerName(player)}: {pct.toFixed(1)}%
              </span>
            </div>
          ))}
          {unclaimed > 0 && (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-gray-400" />
              <span className="text-sm font-medium text-gray-700">
                Unclaimed: {unclaimed.toFixed(1)}%
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}