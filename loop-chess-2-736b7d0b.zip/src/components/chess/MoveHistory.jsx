
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { History, Swords, Crown, Skull } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { getSquareLabel } from './GameEngine';

const PLAYER_COLORS = ['text-blue-600', 'text-red-600', 'text-green-600', 'text-purple-600'];
const PLAYER_NAMES = ['Azure', 'Crimson', 'Emerald', 'Amethyst'];

export default function MoveHistory({ moveHistory, playerColors }) {
  const getPlayerColor = (player) => {
    if (playerColors && playerColors[player]) { // Ensure playerColors[player] exists
      return playerColors[player].main;
    }
    // Fallback to tailwind classes if playerColors is not provided or incomplete
    const tailwindClass = PLAYER_COLORS[player];
    // Extract actual hex/rgb value if possible, otherwise return the class itself
    // For simplicity, directly returning the class here, but for 'style' attribute,
    // we ideally need a direct color value. Since the prompt implies `playerColors[player].main`
    // will be a direct color, I'll adapt this. If playerColors is not used, the inline style
    // will be undefined, so the class applied before would not work.
    // Let's assume if playerColors is not provided, we won't use inline style.
    // Re-evaluating: The outline explicitly uses `style={{ color: getPlayerColor(move.player) }}`
    // which means getPlayerColor must return a direct color string (e.g., "#HEX" or "rgb(...)"),
    // not a Tailwind CSS class. I need to make PLAYER_COLORS also return direct colors.
    const defaultColors = ['#2563EB', '#DC2626', '#16A34A', '#9333EA']; // Corresponding hex for tailwind classes
    return defaultColors[player];
  };

  const getPlayerName = (player) => {
    if (playerColors && playerColors[player]) { // Ensure playerColors[player] exists
      return playerColors[player].name;
    }
    return PLAYER_NAMES[player];
  };

  return (
    <Card className="shadow-xl h-full">
      <CardHeader className="border-b bg-gradient-to-r from-slate-50 to-slate-100">
        <CardTitle className="flex items-center gap-2 text-xl">
          <History className="w-5 h-5" />
          Move History
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-96 p-4">
          <div className="space-y-2">
            {moveHistory.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                No moves yet. Start the simulation!
              </div>
            ) : (
              moveHistory.map((move, idx) => (
                <div 
                  key={idx}
                  className="p-3 bg-gray-50 rounded-lg border border-gray-200 hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-gray-500">
                        #{idx + 1}
                      </span>
                      <span 
                        className="font-semibold"
                        style={{ color: getPlayerColor(move.player) }}
                      >
                        P{move.player + 1} {getPlayerName(move.player)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {move.captured && (
                        <Badge variant="destructive" className="text-xs flex items-center gap-1">
                          <Swords className="w-3 h-3" />
                          Captured {move.captured.type}
                        </Badge>
                      )}
                      {move.capturedKing && (
                        <Badge className="bg-red-600 text-white text-xs flex items-center gap-1">
                          <Skull className="w-3 h-3" />
                          KING SLAIN!
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="mt-1 text-sm text-gray-600 font-mono">
                    {move.piece} {getSquareLabel(move.from.row, move.from.col)} → {getSquareLabel(move.to.row, move.to.col)}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
