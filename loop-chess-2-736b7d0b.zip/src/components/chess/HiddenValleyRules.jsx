
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Sparkles, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function HiddenValleyRules({ hiddenValleyTracking, playerColors }) {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const hasActivePromotion = Object.keys(hiddenValleyTracking).length > 0;
  
  return (
    <Card className="mb-6 bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200">
      <CardHeader 
        className="cursor-pointer hover:bg-purple-100/50 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <CardTitle className="text-xl">Hidden Valley Queen Promotion</CardTitle>
            {hasActivePromotion && (
              <Badge className="bg-purple-600 text-white animate-pulse">
                Active!
              </Badge>
            )}
          </div>
          <Button variant="ghost" size="sm">
            {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </Button>
        </div>
      </CardHeader>
      
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <CardContent className="space-y-4">
              <div className="bg-white rounded-lg p-4 border border-purple-200">
                <h4 className="font-semibold text-gray-900 mb-2">🕳️ Special Rule: The Hidden Valleys</h4>
                <p className="text-gray-700 leading-relaxed">
                  Four mystical pairs of squares exist within the mountain range, called the <span className="font-bold text-purple-600">Hidden Valleys</span> (marked with 🕳️):
                </p>
                <ul className="mt-2 space-y-1 text-gray-700 list-disc list-inside">
                  <li><span className="font-semibold">West Valley:</span> h10 & h11</li>
                  <li><span className="font-semibold">North Valley:</span> j8 & k8</li>
                  <li><span className="font-semibold">South Valley:</span> j13 & k13</li>
                  <li><span className="font-semibold">East Valley:</span> m10 & m11</li>
                </ul>
                <p className="text-gray-700 leading-relaxed mt-3">
                  If you position <span className="font-bold">two of your pawns</span> on both squares of any Hidden Valley and keep them there safely for <span className="font-bold text-purple-600">3 full rounds</span> (where each player takes a turn), 
                  they will be sacrificed to summon a powerful <span className="font-bold">Queen</span>! 
                </p>
                <p className="text-gray-700 leading-relaxed mt-2">
                  The Queen will appear randomly on one of the two pawn squares, while both pawns vanish. Any player can achieve this promotion in any valley - a risky but potentially game-changing strategy!
                </p>
              </div>
              
              {hasActivePromotion && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Active Promotions:</h4>
                  {Object.entries(hiddenValleyTracking).map(([key, data]) => {
                    const player = parseInt(key.split('-')[0]);
                    const grandTurns = Math.ceil(data.turns / 4); // Assuming 4 players, 4 player turns make 1 full round
                    const turnsRemaining = 3 - grandTurns; // 3 full rounds required
                    const playerName = playerColors ? playerColors[player].name : `Player ${player + 1}`;
                    
                    return (
                      <div 
                        key={key}
                        className="bg-white rounded-lg p-3 border-2 border-purple-300 flex items-center justify-between"
                      >
                        <div>
                          <span className="font-semibold" style={{ color: playerColors?.[player]?.main || '#6B21A8' }}>
                            {playerName}
                          </span>
                          <span className="text-gray-600 ml-2">
                            in {data.valleyName} Valley - {turnsRemaining} round{turnsRemaining !== 1 ? 's' : ''} until Queen!
                          </span>
                        </div>
                        <Badge className="bg-purple-600 text-white">
                          Round {grandTurns}/3
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}
