import { isPlayable } from './BoardGeometry';

// Hidden Valley pairs - 4 pairs of squares for queen promotion
export const HIDDEN_VALLEY_PAIRS = [
  { name: 'West', squares: ['9,7', '10,7'] },
  { name: 'South', squares: ['12,9', '12,10'] },
  { name: 'East', squares: ['9,12', '10,12'] },
  { name: 'North', squares: ['7,9', '7,10'] }
];

export const HIDDEN_VALLEY_SQUARES = HIDDEN_VALLEY_PAIRS.flatMap(pair => pair.squares);

// Sliding piece movement (rook, bishop, queen) with 7-square maximum
const getSlidingMoves = (board, row, col, piece, directions, maxDistance = 7) => {
  const moves = [];
  
  for (const [dr, dc] of directions) {
    for (let i = 1; i <= maxDistance; i++) {
      const newRow = row + dr * i;
      const newCol = col + dc * i;
      
      if (!isPlayable(newRow, newCol)) break;
      
      const target = board[`${newRow},${newCol}`];
      if (target) {
        if (!target.alive || target.owner !== piece.owner) {
          moves.push({ row: newRow, col: newCol });
        }
        break;
      }
      moves.push({ row: newRow, col: newCol });
    }
  }
  
  return moves;
};

// King movement with proper castling
const getKingMoves = (board, row, col, piece) => {
  const moves = [];
  
  // Regular king moves
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      const newRow = row + dr;
      const newCol = col + dc;
      
      if (isPlayable(newRow, newCol)) {
        const target = board[`${newRow},${newCol}`];
        if (!target || !target.alive || target.owner !== piece.owner) {
          moves.push({ row: newRow, col: newCol });
        }
      }
    }
  }
  
  // Castling logic - king must not have moved
  if (!piece.hasMoved) {
    const player = piece.player;
    
    if (player === 0) { // North - horizontal at row 0
      // Kingside (toward right rook at col 13) - King to col 12, Rook to col 11
      const kingsideRook = board['0,13'];
      if (kingsideRook && kingsideRook.type === 'rook' && !kingsideRook.hasMoved) {
        let canCastle = true;
        for (let c = col + 1; c < 13; c++) {
          if (board[`0,${c}`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 0, col: 12, isCastling: true, isKingside: true });
      }
      
      // Queenside (toward left rook at col 6) - King to col 8, Rook to col 9
      const queensideRook = board['0,6'];
      if (queensideRook && queensideRook.type === 'rook' && !queensideRook.hasMoved) {
        let canCastle = true;
        for (let c = col - 1; c > 6; c--) {
          if (board[`0,${c}`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 0, col: 8, isCastling: true, isKingside: false });
      }
    } else if (player === 1) { // East - vertical at col 19
      // Kingside (toward bottom rook at row 13) - King to row 12, Rook to row 11
      const kingsideRook = board['13,19'];
      if (kingsideRook && kingsideRook.type === 'rook' && !kingsideRook.hasMoved) {
        let canCastle = true;
        for (let r = row + 1; r < 13; r++) {
          if (board[`${r},19`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 12, col: 19, isCastling: true, isKingside: true });
      }
      
      // Queenside (toward top rook at row 6) - King to row 8, Rook to row 9
      const queensideRook = board['6,19'];
      if (queensideRook && queensideRook.type === 'rook' && !queensideRook.hasMoved) {
        let canCastle = true;
        for (let r = row - 1; r > 6; r--) {
          if (board[`${r},19`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 8, col: 19, isCastling: true, isKingside: false });
      }
    } else if (player === 2) { // South - horizontal at row 19
      // Kingside (toward right rook at col 13) - King to col 12, Rook to col 11
      const kingsideRook = board['19,13'];
      if (kingsideRook && kingsideRook.type === 'rook' && !kingsideRook.hasMoved) {
        let canCastle = true;
        for (let c = col + 1; c < 13; c++) {
          if (board[`19,${c}`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 19, col: 12, isCastling: true, isKingside: true });
      }
      
      // Queenside (toward left rook at col 6) - King to col 8, Rook to col 9
      const queensideRook = board['19,6'];
      if (queensideRook && queensideRook.type === 'rook' && !queensideRook.hasMoved) {
        let canCastle = true;
        for (let c = col - 1; c > 6; c--) {
          if (board[`19,${c}`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 19, col: 8, isCastling: true, isKingside: false });
      }
    } else if (player === 3) { // West - vertical at col 0
      // Kingside (toward bottom rook at row 13) - King to row 12, Rook to row 11
      const kingsideRook = board['13,0'];
      if (kingsideRook && kingsideRook.type === 'rook' && !kingsideRook.hasMoved) {
        let canCastle = true;
        for (let r = row + 1; r < 13; r++) {
          if (board[`${r},0`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 12, col: 0, isCastling: true, isKingside: true });
      }
      
      // Queenside (toward top rook at row 6) - King to row 8, Rook to row 9
      const queensideRook = board['6,0'];
      if (queensideRook && queensideRook.type === 'rook' && !queensideRook.hasMoved) {
        let canCastle = true;
        for (let r = row - 1; r > 6; r--) {
          if (board[`${r},0`]) {
            canCastle = false;
            break;
          }
        }
        if (canCastle) moves.push({ row: 8, col: 0, isCastling: true, isKingside: false });
      }
    }
  }
  
  return moves;
};

// Pawn movement - CANNOT move to edge squares (row/col 0 or 19)
const getPawnMoves = (board, row, col, piece, lastMove) => {
  const moves = [];
  
  // Pawns can move in all 8 directions
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      
      const newRow = row + dr;
      const newCol = col + dc;
      
      // RULE: Pawns CANNOT move to edge squares (back ranks/files)
      if (newRow === 0 || newRow === 19 || newCol === 0 || newCol === 19) continue;
      
      if (!isPlayable(newRow, newCol)) continue;
      
      const target = board[`${newRow},${newCol}`];
      
      // Can move to any adjacent square that's empty or has an enemy/dead piece
      if (!target || !target.alive || target.owner !== piece.owner) {
        moves.push({ row: newRow, col: newCol });
      }
      
      // En passant for diagonal moves
      if (dr !== 0 && dc !== 0 && !target && lastMove) {
        const lastPiece = board[`${lastMove.to.row},${lastMove.to.col}`];
        if (lastPiece && lastPiece.type === 'pawn' &&
            Math.abs(lastMove.from.row - lastMove.to.row) === 2 &&
            Math.abs(lastMove.from.col - lastMove.to.col) === 2 &&
            lastMove.to.row === row && lastMove.to.col === newCol) {
          moves.push({ row: newRow, col: newCol, isEnPassant: true });
        }
      }
    }
  }
  
  // Two-square initial move in any direction (but NOT to edges)
  if (!piece.hasMoved) {
    for (let dr = -2; dr <= 2; dr++) {
      for (let dc = -2; dc <= 2; dc++) {
        if ((Math.abs(dr) !== 2 && Math.abs(dc) !== 2) || (dr === 0 && dc === 0)) continue;
        if (Math.abs(dr) === 2 && Math.abs(dc) === 2) continue;
        
        const twoRow = row + dr;
        const twoCol = col + dc;
        
        // RULE: Pawns CANNOT move to edge squares
        if (twoRow === 0 || twoRow === 19 || twoCol === 0 || twoCol === 19) continue;
        
        const midRow = row + Math.sign(dr);
        const midCol = col + Math.sign(dc);
        
        const midTarget = board[`${midRow},${midCol}`];
        const twoTarget = board[`${twoRow},${twoCol}`];
        
        if (isPlayable(twoRow, twoCol) && 
            (!midTarget || !midTarget.alive) && 
            (!twoTarget || !twoTarget.alive)) {
          moves.push({ row: twoRow, col: twoCol, isPawnDoubleMove: true });
        }
      }
    }
  }
  
  return moves;
};

// Knight movement
const getKnightMoves = (board, row, col, piece) => {
  const moves = [];
  const knightOffsets = [
    [-2, -1], [-2, 1], [-1, -2], [-1, 2],
    [1, -2], [1, 2], [2, -1], [2, 1]
  ];
  
  for (const [dr, dc] of knightOffsets) {
    const newRow = row + dr;
    const newCol = col + dc;
    
    if (isPlayable(newRow, newCol)) {
      const target = board[`${newRow},${newCol}`];
      if (!target || !target.alive || target.owner !== piece.owner) {
        moves.push({ row: newRow, col: newCol });
      }
    }
  }
  
  return moves;
};

export const getValidMoves = (board, row, col, piece, lastMove) => {
  if (!piece.alive) return [];
  
  switch (piece.type) {
    case 'pawn':
      return getPawnMoves(board, row, col, piece, lastMove);
      
    case 'king':
      return getKingMoves(board, row, col, piece);
      
    case 'queen':
      return getSlidingMoves(board, row, col, piece, [
        [-1, 0], [1, 0], [0, -1], [0, 1],
        [-1, -1], [-1, 1], [1, -1], [1, 1]
      ], 7);
      
    case 'rook':
      return getSlidingMoves(board, row, col, piece, [
        [-1, 0], [1, 0], [0, -1], [0, 1]
      ], 7);
      
    case 'bishop':
      return getSlidingMoves(board, row, col, piece, [
        [-1, -1], [-1, 1], [1, -1], [1, 1]
      ], 7);
      
    case 'knight':
      return getKnightMoves(board, row, col, piece);
      
    default:
      return [];
  }
};