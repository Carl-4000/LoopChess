import React from 'react';
import { motion } from 'framer-motion';

const PIECE_SYMBOLS = {
  'king': '♔',
  'queen': '♕',
  'rook': '♖',
  'bishop': '♗',
  'knight': '♘',
  'pawn': '♙'
};

export default function ChessPiece({ piece, perspective, playerColors }) {
  const bgColor = piece.alive 
    ? (playerColors?.[piece.owner]?.main || `hsl(${piece.owner * 90}, 70%, 50%)`)
    : 'rgb(107, 114, 128)';
  
  const textColor = piece.alive ? 'white' : 'rgb(209, 213, 219)';
  const opacity = piece.alive ? 'opacity-100' : 'opacity-50';
  
  return (
    <motion.div
      className={`absolute inset-0 flex items-center justify-center ${opacity}
        rounded-md text-2xl font-bold shadow-lg`}
      style={{
        backgroundColor: bgColor,
        color: textColor
      }}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      whileHover={piece.alive ? { scale: 1.1 } : {}}
    >
      {PIECE_SYMBOLS[piece.type]}
      {!piece.alive && (
        <div className="absolute inset-0 flex items-center justify-center text-red-600 text-3xl font-bold">
          ✕
        </div>
      )}
    </motion.div>
  );
}