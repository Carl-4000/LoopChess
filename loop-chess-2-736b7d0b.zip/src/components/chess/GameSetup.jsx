import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Users, Brain, Play, Palette } from 'lucide-react';

const DEFAULT_COLORS = [
  { name: 'Azure', main: '#3B82F6', light: '#BFDBFE', dark: '#1E40AF' },
  { name: 'Crimson', main: '#EF4444', light: '#FECACA', dark: '#991B1B' },
  { name: 'Emerald', main: '#10B981', light: '#A7F3D0', dark: '#065F46' },
  { name: 'Amethyst', main: '#A855F7', light: '#E9D5FF', dark: '#6B21A8' }
];

const POSITION_NAMES = ['North', 'East', 'South', 'West'];

export default function GameSetup({ onStartGame }) {
  const [humanPlayers, setHumanPlayers] = useState([]);
  const [thinkingTime, setThinkingTime] = useState(1000);
  const [playerCustomizations, setPlayerCustomizations] = useState(DEFAULT_COLORS);

  const togglePlayer = (playerIndex) => {
    if (humanPlayers.includes(playerIndex)) {
      setHumanPlayers(humanPlayers.filter(p => p !== playerIndex));
    } else {
      setHumanPlayers([...humanPlayers, playerIndex]);
    }
  };

  const updatePlayerColor = (playerIndex, field, value) => {
    const newCustomizations = [...playerCustomizations];
    newCustomizations[playerIndex] = {
      ...newCustomizations[playerIndex],
      [field]: value
    };
    setPlayerCustomizations(newCustomizations);
  };

  const handleStartGame = () => {
    onStartGame({
      humanPlayers,
      thinkingTime,
      playerColors: playerCustomizations
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-slate-100 p-6 flex items-center justify-center">
      <Card className="w-full max-w-4xl shadow-2xl">
        <CardHeader className="border-b bg-gradient-to-r from-slate-50 to-slate-100">
          <CardTitle className="text-3xl font-bold text-center">
            Donut Chess Setup
          </CardTitle>
          <p className="text-center text-gray-600 mt-2">
            Configure your 4-player chess game
          </p>
        </CardHeader>
        
        <CardContent className="p-8 space-y-8">
          {/* Player Selection */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Users className="w-6 h-6 text-gray-700" />
              <h3 className="text-xl font-semibold">Select Players & Customize</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[0, 1, 2, 3].map((playerIndex) => {
                const isHuman = humanPlayers.includes(playerIndex);
                const custom = playerCustomizations[playerIndex];
                
                return (
                  <div
                    key={playerIndex}
                    className={`
                      p-6 rounded-xl border-2 transition-all duration-200
                      ${isHuman 
                        ? 'border-yellow-400 bg-yellow-50 ring-4 ring-yellow-200' 
                        : 'border-gray-300 bg-white'
                      }
                    `}
                  >
                    <button
                      onClick={() => togglePlayer(playerIndex)}
                      className="w-full mb-4"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-lg">
                          Player {playerIndex + 1} ({POSITION_NAMES[playerIndex]})
                        </span>
                        <Badge className={isHuman ? 'bg-green-500' : 'bg-blue-500'}>
                          {isHuman ? 'Human' : 'AI'}
                        </Badge>
                      </div>
                    </button>
                    
                    <div className="space-y-3">
                      <Input
                        placeholder="Army Name"
                        value={custom.name}
                        onChange={(e) => updatePlayerColor(playerIndex, 'name', e.target.value)}
                        className="text-sm"
                      />
                      
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <label className="text-xs text-gray-600 mb-1 block">Main Color</label>
                          <input
                            type="color"
                            value={custom.main}
                            onChange={(e) => updatePlayerColor(playerIndex, 'main', e.target.value)}
                            className="w-full h-10 rounded cursor-pointer"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-600 mb-1 block">Light Shade</label>
                          <input
                            type="color"
                            value={custom.light}
                            onChange={(e) => updatePlayerColor(playerIndex, 'light', e.target.value)}
                            className="w-full h-10 rounded cursor-pointer"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-600 mb-1 block">Dark Shade</label>
                          <input
                            type="color"
                            value={custom.dark}
                            onChange={(e) => updatePlayerColor(playerIndex, 'dark', e.target.value)}
                            className="w-full h-10 rounded cursor-pointer"
                          />
                        </div>
                      </div>
                      
                      <div 
                        className="h-12 rounded-lg flex items-center justify-center text-white font-semibold"
                        style={{ backgroundColor: custom.main }}
                      >
                        {custom.name}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="mt-4 text-center">
              <Badge variant="outline" className="text-base py-2 px-4">
                {humanPlayers.length} Human · {4 - humanPlayers.length} AI
              </Badge>
            </div>
          </div>

          {/* AI Thinking Time */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Brain className="w-6 h-6 text-gray-700" />
              <h3 className="text-xl font-semibold">AI Thinking Time</h3>
            </div>
            
            <div className="space-y-4">
              <Slider
                value={[thinkingTime]}
                onValueChange={(value) => setThinkingTime(value[0])}
                min={500}
                max={5000}
                step={500}
                className="w-full"
              />
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Fast (0.5s)</span>
                <Badge className="text-lg px-4 py-1">
                  {(thinkingTime / 1000).toFixed(1)}s
                </Badge>
                <span className="text-gray-500">Deep (5.0s)</span>
              </div>
            </div>
          </div>

          {/* Start Button */}
          <Button
            onClick={handleStartGame}
            className="w-full h-14 text-lg bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            <Play className="w-6 h-6 mr-3" />
            Start Game
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}