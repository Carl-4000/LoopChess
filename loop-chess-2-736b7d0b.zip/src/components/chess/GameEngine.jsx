import { isPlayable, getAllPlayableSquares } from './BoardGeometry';
import { getValidMoves } from './PieceMovement';

export { isPlayable, getSquareType, getSquareLabel } from './BoardGeometry';
export { getValidMoves } from './PieceMovement';

export const initializeBoard = () => {
  const board = {};
  
  // Player 0 (North/Azure) - Horizontal layout at top
  board['0,6'] = { type: 'rook', player: 0, owner: 0, alive: true, hasMoved: false };
  board['0,7'] = { type: 'knight', player: 0, owner: 0, alive: true, hasMoved: false };
  board['0,8'] = { type: 'bishop', player: 0, owner: 0, alive: true, hasMoved: false };
  board['0,9'] = { type: 'queen', player: 0, owner: 0, alive: true, hasMoved: false };
  board['0,10'] = { type: 'king', player: 0, owner: 0, alive: true, hasMoved: false };
  board['0,11'] = { type: 'bishop', player: 0, owner: 0, alive: true, hasMoved: false };
  board['0,12'] = { type: 'knight', player: 0, owner: 0, alive: true, hasMoved: false };
  board['0,13'] = { type: 'rook', player: 0, owner: 0, alive: true, hasMoved: false };
  for (let col = 6; col <= 13; col++) {
    board[`1,${col}`] = { type: 'pawn', player: 0, owner: 0, alive: true, hasMoved: false };
  }
  
  // Player 1 (East/Crimson) - Vertical layout on right
  board['6,19'] = { type: 'rook', player: 1, owner: 1, alive: true, hasMoved: false };
  board['7,19'] = { type: 'knight', player: 1, owner: 1, alive: true, hasMoved: false };
  board['8,19'] = { type: 'bishop', player: 1, owner: 1, alive: true, hasMoved: false };
  board['9,19'] = { type: 'queen', player: 1, owner: 1, alive: true, hasMoved: false };
  board['10,19'] = { type: 'king', player: 1, owner: 1, alive: true, hasMoved: false };
  board['11,19'] = { type: 'bishop', player: 1, owner: 1, alive: true, hasMoved: false };
  board['12,19'] = { type: 'knight', player: 1, owner: 1, alive: true, hasMoved: false };
  board['13,19'] = { type: 'rook', player: 1, owner: 1, alive: true, hasMoved: false };
  for (let row = 6; row <= 13; row++) {
    board[`${row},18`] = { type: 'pawn', player: 1, owner: 1, alive: true, hasMoved: false };
  }
  
  // Player 2 (South/Emerald) - Horizontal layout at bottom
  board['19,6'] = { type: 'rook', player: 2, owner: 2, alive: true, hasMoved: false };
  board['19,7'] = { type: 'knight', player: 2, owner: 2, alive: true, hasMoved: false };
  board['19,8'] = { type: 'bishop', player: 2, owner: 2, alive: true, hasMoved: false };
  board['19,9'] = { type: 'queen', player: 2, owner: 2, alive: true, hasMoved: false };
  board['19,10'] = { type: 'king', player: 2, owner: 2, alive: true, hasMoved: false };
  board['19,11'] = { type: 'bishop', player: 2, owner: 2, alive: true, hasMoved: false };
  board['19,12'] = { type: 'knight', player: 2, owner: 2, alive: true, hasMoved: false };
  board['19,13'] = { type: 'rook', player: 2, owner: 2, alive: true, hasMoved: false };
  for (let col = 6; col <= 13; col++) {
    board[`18,${col}`] = { type: 'pawn', player: 2, owner: 2, alive: true, hasMoved: false };
  }
  
  // Player 3 (West/Amethyst) - Vertical layout on left
  board['6,0'] = { type: 'rook', player: 3, owner: 3, alive: true, hasMoved: false };
  board['7,0'] = { type: 'knight', player: 3, owner: 3, alive: true, hasMoved: false };
  board['8,0'] = { type: 'bishop', player: 3, owner: 3, alive: true, hasMoved: false };
  board['9,0'] = { type: 'queen', player: 3, owner: 3, alive: true, hasMoved: false };
  board['10,0'] = { type: 'king', player: 3, owner: 3, alive: true, hasMoved: false };
  board['11,0'] = { type: 'bishop', player: 3, owner: 3, alive: true, hasMoved: false };
  board['12,0'] = { type: 'knight', player: 3, owner: 3, alive: true, hasMoved: false };
  board['13,0'] = { type: 'rook', player: 3, owner: 3, alive: true, hasMoved: false };
  for (let row = 6; row <= 13; row++) {
    board[`${row},1`] = { type: 'pawn', player: 3, owner: 3, alive: true, hasMoved: false };
  }
  
  return board;
};

export const makeMove = (board, fromRow, fromCol, toRow, toCol, lastMove = null) => {
  const newBoard = { ...board };
  const piece = newBoard[`${fromRow},${fromCol}`];
  const captured = newBoard[`${toRow},${toCol}`];
  
  // Handle castling - move rook to correct position
  if (piece.type === 'king' && !piece.hasMoved) {
    const player = piece.player;
    const colDiff = toCol - fromCol;
    const rowDiff = toRow - fromRow;
    
    if (player === 0 && fromRow === toRow && Math.abs(colDiff) >= 2) {
      if (colDiff > 0) {
        const rook = newBoard['0,13'];
        if (rook) {
          newBoard['0,11'] = { ...rook, hasMoved: true };
          delete newBoard['0,13'];
        }
      } else {
        const rook = newBoard['0,6'];
        if (rook) {
          newBoard['0,9'] = { ...rook, hasMoved: true };
          delete newBoard['0,6'];
        }
      }
    } else if (player === 1 && fromCol === toCol && Math.abs(rowDiff) >= 2) {
      if (rowDiff > 0) {
        const rook = newBoard['13,19'];
        if (rook) {
          newBoard['11,19'] = { ...rook, hasMoved: true };
          delete newBoard['13,19'];
        }
      } else {
        const rook = newBoard['6,19'];
        if (rook) {
          newBoard['9,19'] = { ...rook, hasMoved: true };
          delete newBoard['6,19'];
        }
      }
    } else if (player === 2 && fromRow === toRow && Math.abs(colDiff) >= 2) {
      if (colDiff > 0) {
        const rook = newBoard['19,13'];
        if (rook) {
          newBoard['19,11'] = { ...rook, hasMoved: true };
          delete newBoard['19,13'];
        }
      } else {
        const rook = newBoard['19,6'];
        if (rook) {
          newBoard['19,9'] = { ...rook, hasMoved: true };
          delete newBoard['19,6'];
        }
      }
    } else if (player === 3 && fromCol === toCol && Math.abs(rowDiff) >= 2) {
      if (rowDiff > 0) {
        const rook = newBoard['13,0'];
        if (rook) {
          newBoard['11,0'] = { ...rook, hasMoved: true };
          delete newBoard['13,0'];
        }
      } else {
        const rook = newBoard['6,0'];
        if (rook) {
          newBoard['9,0'] = { ...rook, hasMoved: true };
          delete newBoard['6,0'];
        }
      }
    }
  }
  
  // Handle en passant
  let enPassantCapture = null;
  if (piece.type === 'pawn' && lastMove) {
    const lastPiece = newBoard[`${lastMove.to.row},${lastMove.to.col}`];
    if (lastPiece && lastPiece.type === 'pawn' && 
        Math.abs(lastMove.from.row - lastMove.to.row) === 2 &&
        Math.abs(lastMove.from.col - lastMove.to.col) === 2 &&
        lastMove.to.row === fromRow && Math.abs(lastMove.to.col - fromCol) === 1 &&
        toRow !== fromRow && toCol === lastMove.to.col) {
      enPassantCapture = lastPiece;
      delete newBoard[`${lastMove.to.row},${lastMove.to.col}`];
    }
  }
  
  // If capturing a dead piece, remove it completely
  if (captured && !captured.alive) {
    delete newBoard[`${toRow},${toCol}`];
  }
  
  newBoard[`${toRow},${toCol}`] = { ...piece, hasMoved: true };
  delete newBoard[`${fromRow},${fromCol}`];
  
  let capturedKingPlayer = null;
  const actualCaptured = captured || enPassantCapture;
  
  if (actualCaptured && actualCaptured.type === 'king' && actualCaptured.alive) {
    capturedKingPlayer = actualCaptured.player;
    
    // Transfer all pieces to the capturing player as dead
    for (const [key, p] of Object.entries(newBoard)) {
      if (p.player === capturedKingPlayer) {
        newBoard[key] = { 
          ...p, 
          alive: false,
          owner: piece.owner
        };
      }
    }
  }
  
  return { board: newBoard, captured: actualCaptured, capturedKingPlayer };
};

// Optimized check detection with early exit
export const isInCheck = (board, player) => {
  let kingPos = null;
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player === player && piece.type === 'king' && piece.alive) {
      kingPos = key;
      break;
    }
  }
  
  if (!kingPos) return false;
  
  const [kingRow, kingCol] = kingPos.split(',').map(Number);
  
  for (const [key, piece] of Object.entries(board)) {
    if (piece.player !== player && piece.alive && piece.owner !== player) {
      const [row, col] = key.split(',').map(Number);
      const moves = getValidMoves(board, row, col, piece, null);
      
      if (moves.some(m => m.row === kingRow && m.col === kingCol)) {
        return true;
      }
    }
  }
  
  return false;
};

// Highly optimized territory calculation with minimal allocations
export const calculateAllTerritories = (board, previousTerritories = {}) => {
  const threatMap = {};
  const territories = {};
  
  // Pre-initialize with playable squares
  const playableSquares = getAllPlayableSquares();
  for (const key of playableSquares) {
    territories[key] = previousTerritories[key] ?? null;
    threatMap[key] = {};
  }
  
  // Single pass through board - calculate all threats
  for (const [key, piece] of Object.entries(board)) {
    if (!piece.alive) continue;
    
    const [row, col] = key.split(',').map(Number);
    const controllingPlayer = piece.owner;
    
    // Piece occupying square
    threatMap[key][controllingPlayer] = (threatMap[key][controllingPlayer] || 0) + 1;
    
    // Threatened squares
    const moves = getValidMoves(board, row, col, piece, null);
    for (const move of moves) {
      const moveKey = `${move.row},${move.col}`;
      if (threatMap[moveKey]) {
        threatMap[moveKey][controllingPlayer] = (threatMap[moveKey][controllingPlayer] || 0) + 1;
      }
    }
  }
  
  // Determine territory ownership
  for (const [key, threats] of Object.entries(threatMap)) {
    const players = Object.keys(threats);
    
    if (players.length === 0) {
      continue;
    } else if (players.length === 1) {
      territories[key] = parseInt(players[0]);
    } else {
      const maxThreats = Math.max(...Object.values(threats));
      const topPlayers = players.filter(p => threats[p] === maxThreats);
      
      if (topPlayers.length === 1) {
        territories[key] = parseInt(topPlayers[0]);
      } else {
        // Deterministic tiebreaker
        const [r, c] = key.split(',').map(Number);
        const tiebreaker = (r + c) % topPlayers.length;
        territories[key] = parseInt(topPlayers[tiebreaker]);
      }
    }
  }
  
  return territories;
};

export const calculateTerritoryPercentages = (territories) => {
  const counts = [0, 0, 0, 0];
  let total = 0;
  
  for (const player of Object.values(territories)) {
    if (player !== null && player !== undefined) {
      counts[player]++;
      total++;
    }
  }
  
  if (total === 0) return { 0: 0, 1: 0, 2: 0, 3: 0 };
  
  return {
    0: (counts[0] / total) * 100,
    1: (counts[1] / total) * 100,
    2: (counts[2] / total) * 100,
    3: (counts[3] / total) * 100
  };
};

export const checkVictoryCondition = (territories) => {
  const percentages = calculateTerritoryPercentages(territories);
  
  for (let player = 0; player < 4; player++) {
    if (percentages[player] >= 75) {
      return player;
    }
  }
  
  return null;
};