import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, RotateCcw, Eye, Zap } from 'lucide-react';

const PLAYER_NAMES = ['Azure (North)', 'Crimson (East)', 'Emerald (South)', 'Amethyst (West)'];

export default function GameControls({ 
  isSimulating,
  onStartSimulation,
  onPauseSimulation,
  onResetGame,
  viewPerspective,
  onViewChange,
  onStepMove,
  moveCount,
  humanPlayers
}) {
  return (
    <Card className="shadow-xl">
      <CardHeader className="border-b bg-gradient-to-r from-slate-50 to-slate-100">
        <CardTitle className="flex items-center gap-2 text-xl">
          <Eye className="w-5 h-5" />
          Game Controls
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-3">
          <label className="text-sm font-medium text-gray-700">
            View Perspective
          </label>
          <Select value={viewPerspective.toString()} onValueChange={(v) => onViewChange(parseInt(v))}>
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PLAYER_NAMES.map((name, idx) => (
                <SelectItem key={idx} value={idx.toString()}>
                  Player {idx + 1} - {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-3">
          {!isSimulating ? (
            <Button 
              onClick={onStartSimulation}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              <Play className="w-4 h-4 mr-2" />
              Auto Simulate
            </Button>
          ) : (
            <Button 
              onClick={onPauseSimulation}
              variant="destructive"
              className="flex-1"
            >
              <Pause className="w-4 h-4 mr-2" />
              Pause
            </Button>
          )}
          
          <Button 
            onClick={onStepMove}
            variant="outline"
            disabled={isSimulating}
            className="flex-1"
          >
            <Zap className="w-4 h-4 mr-2" />
            Step Move
          </Button>
        </div>

        <Button 
          onClick={onResetGame}
          variant="outline"
          className="w-full"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset Game
        </Button>

        <div className="pt-4 border-t">
          <div className="text-center">
            <div className="text-sm text-gray-500 mb-1">Total Moves</div>
            <div className="text-3xl font-bold text-gray-900">{moveCount}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}