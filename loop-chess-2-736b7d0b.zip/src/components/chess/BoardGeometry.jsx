// Centralized board geometry and validation utilities
export const BOARD_SIZE = 20;
export const CENTER = BOARD_SIZE / 2;
export const INNER_RADIUS = 2.5;
export const OUTER_RADIUS = 10.5;

export const EXTRA_MOUNTAINS = [
  [6, 9], [6, 10],
  [13, 9], [13, 10],
  [9, 6], [10, 6],
  [9, 13], [10, 13],
  [7, 8], [7, 11], [8, 7], [8, 12],
  [11, 7], [11, 12], [12, 8], [12, 11]
];

// Pre-compute playable squares for O(1) lookup
const PLAYABLE_SQUARES_SET = new Set();
for (let row = 0; row < BOARD_SIZE; row++) {
  for (let col = 0; col < BOARD_SIZE; col++) {
    if (EXTRA_MOUNTAINS.some(([r, c]) => r === row && c === col)) continue;
    
    const dx = col - CENTER + 0.5;
    const dy = row - CENTER + 0.5;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance >= INNER_RADIUS && distance <= OUTER_RADIUS) {
      PLAYABLE_SQUARES_SET.add(`${row},${col}`);
    }
  }
}

export const isPlayable = (row, col) => {
  if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) return false;
  return PLAYABLE_SQUARES_SET.has(`${row},${col}`);
};

export const getSquareType = (row, col) => {
  if (EXTRA_MOUNTAINS.some(([r, c]) => r === row && c === col)) return 'mountain';
  
  const dx = col - CENTER + 0.5;
  const dy = row - CENTER + 0.5;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  if (distance < INNER_RADIUS) return 'mountain';
  if (distance > OUTER_RADIUS) return 'ocean';
  return 'playable';
};

export const getSquareLabel = (row, col) => {
  const colLabel = String.fromCharCode(97 + col);
  const rowLabel = row + 1;
  return `${colLabel}${rowLabel}`;
};

// Get all playable squares (cached)
export const getAllPlayableSquares = () => {
  return Array.from(PLAYABLE_SQUARES_SET);
};