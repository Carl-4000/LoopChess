import { base44 } from './base44Client';


export const GameState = base44.entities.GameState;



// auth sdk:
export const User = base44.auth;