import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Crown, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';

import GameSetup from '../components/chess/GameSetup';
import GameBoard from '../components/chess/GameBoard';
import ScoreBoard from '../components/chess/ScoreBoard';
import GameControls from '../components/chess/GameControls';
import MoveHistory from '../components/chess/MoveHistory';
import TerritoryBar from '../components/chess/TerritoryBar';
import HiddenValleyRules from '../components/chess/HiddenValleyRules';
import { 
  initializeBoard, 
  getValidMoves, 
  makeMove,
  calculateAllTerritories,
  calculateTerritoryPercentages,
  checkVictoryCondition
} from '../components/chess/GameEngine';
import { makeAIMove } from '../components/chess/AIEngine';
import { HIDDEN_VALLEY_PAIRS, HIDDEN_VALLEY_SQUARES } from '../components/chess/PieceMovement';

export default function DonutChess() {
  const [gameStarted, setGameStarted] = useState(false);
  const [humanPlayers, setHumanPlayers] = useState([]);
  const [thinkingTime, setThinkingTime] = useState(1000);
  const [playerColors, setPlayerColors] = useState(null);
  
  const [boardState, setBoardState] = useState(() => initializeBoard());
  const [currentTurn, setCurrentTurn] = useState(0);
  const [moveHistory, setMoveHistory] = useState([]);
  const [boardHistory, setBoardHistory] = useState([initializeBoard()]);
  const [historyPosition, setHistoryPosition] = useState(0);
  const [eliminatedPlayers, setEliminatedPlayers] = useState([]);
  const [gameStatus, setGameStatus] = useState('active');
  const [isSimulating, setIsSimulating] = useState(false);
  const [viewPerspective, setViewPerspective] = useState(0);
  const [selectedSquare, setSelectedSquare] = useState(null);
  const [validMoves, setValidMoves] = useState([]);
  const [winner, setWinner] = useState(null);
  const [territories, setTerritories] = useState({});
  const [territoryPercentages, setTerritoryPercentages] = useState({ 0: 0, 1: 0, 2: 0, 3: 0 });
  const [isAIThinking, setIsAIThinking] = useState(false);
  const [lastMove, setLastMove] = useState(null);
  const [hiddenValleyTracking, setHiddenValleyTracking] = useState({});
  const [queenPromotionAlert, setQueenPromotionAlert] = useState(null);
  
  const simulationInterval = useRef(null);

  // Create audio element for move sound
  const moveSound = useRef(null);
  
  useEffect(() => {
    // Create a simple wood thud sound using Web Audio API
    moveSound.current = () => {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 80;
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.1);
    };
  }, []);

  // Keyboard navigation for move history
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (historyPosition > 0) {
          setHistoryPosition(historyPosition - 1);
        }
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (historyPosition < boardHistory.length - 1) {
          setHistoryPosition(historyPosition + 1);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [historyPosition, boardHistory.length]);

  // Display board from history position
  const displayBoard = boardHistory[historyPosition] || boardState;
  const isViewingHistory = historyPosition < boardHistory.length - 1;

  useEffect(() => {
    const newTerritories = calculateAllTerritories(displayBoard, territories);
    setTerritories(newTerritories);
    setTerritoryPercentages(calculateTerritoryPercentages(newTerritories));
  }, [displayBoard]);

  // Track Hidden Valley occupancy - increment every turn, display as grand-turns
  useEffect(() => {
    const newTracking = { ...hiddenValleyTracking };
    
    // Check all players' pawns in valleys every turn
    for (let player = 0; player < 4; player++) {
      for (const valley of HIDDEN_VALLEY_PAIRS) {
        const pawnsInValley = valley.squares.filter(square => {
          const piece = boardState[square];
          return piece && piece.type === 'pawn' && piece.owner === player && piece.alive;
        });
        
        const key = `${player}-${valley.name}`;
        
        if (pawnsInValley.length === 2) {
          if (!newTracking[key]) {
            newTracking[key] = { turns: 1, squares: pawnsInValley, valleyName: valley.name };
          } else {
            newTracking[key].turns += 1;
            
            // After 12 total turns (3 grand-turns), promote to queen!
            if (newTracking[key].turns >= 12) {
              const randomSquare = pawnsInValley[Math.floor(Math.random() * 2)];
              const newBoard = { ...boardState };
              
              pawnsInValley.forEach(sq => delete newBoard[sq]);
              
              newBoard[randomSquare] = {
                type: 'queen',
                player: player,
                owner: player,
                alive: true,
                hasMoved: true
              };
              
              setBoardState(newBoard);
              setBoardHistory([...boardHistory, newBoard]);
              setHistoryPosition(boardHistory.length);
              setQueenPromotionAlert({ player, square: randomSquare, valley: valley.name });
              setTimeout(() => setQueenPromotionAlert(null), 5000);
              
              delete newTracking[key];
            }
          }
        } else {
          // Reset if pawns leave the valley
          delete newTracking[key];
        }
      }
    }
    
    setHiddenValleyTracking(newTracking);
  }, [currentTurn]);

  // Check for victory by king capture - if only 1 king remains alive
  const checkKingCaptureVictory = (board) => {
    const aliveKings = [];
    for (const [key, piece] of Object.entries(board)) {
      if (piece.type === 'king' && piece.alive) {
        aliveKings.push(piece.player);
      }
    }
    
    if (aliveKings.length === 1) {
      return aliveKings[0];
    }
    return null;
  };

  const handleGameSetup = ({ humanPlayers: players, thinkingTime: time, playerColors: colors }) => {
    setHumanPlayers(players);
    setThinkingTime(time);
    setPlayerColors(colors);
    setGameStarted(true);
    
    if (players.length === 0) {
      setIsSimulating(true);
    }
  };

  const executeAIMove = async () => {
    if (gameStatus !== 'active') return;
    
    let activePlayer = currentTurn;
    let attempts = 0;
    
    while (eliminatedPlayers.includes(activePlayer) && attempts < 4) {
      activePlayer = (activePlayer + 1) % 4;
      attempts++;
    }
    
    if (attempts >= 4) {
      setGameStatus('completed');
      return;
    }
    
    if (humanPlayers.includes(activePlayer)) {
      return;
    }
    
    setIsAIThinking(true);
    
    await new Promise(resolve => setTimeout(resolve, thinkingTime));
    
    const aiResult = makeAIMove(boardState, activePlayer, eliminatedPlayers, territories, thinkingTime, lastMove);
    
    setIsAIThinking(false);
    
    if (!aiResult) {
      setEliminatedPlayers([...eliminatedPlayers, activePlayer]);
      let nextPlayer = (activePlayer + 1) % 4;
      let searchAttempts = 0;
      while (eliminatedPlayers.includes(nextPlayer) && searchAttempts < 4) {
        nextPlayer = (nextPlayer + 1) % 4;
        searchAttempts++;
      }
      setCurrentTurn(nextPlayer);
      return;
    }
    
    const aiMove = aiResult.move;
    const { board: newBoard, captured, capturedKingPlayer } = makeMove(
      boardState,
      aiMove.from.row,
      aiMove.from.col,
      aiMove.to.row,
      aiMove.to.col,
      lastMove
    );
    
    // Play move sound
    if (moveSound.current) moveSound.current();
    
    const piece = boardState[`${aiMove.from.row},${aiMove.from.col}`];
    
    let newEliminated = [...eliminatedPlayers];
    if (capturedKingPlayer !== null) {
      newEliminated.push(capturedKingPlayer);
      setEliminatedPlayers(newEliminated);
    }
    
    const newMoveRecord = {
      player: activePlayer,
      piece: piece.type,
      from: aiMove.from,
      to: aiMove.to,
      captured,
      capturedKing: capturedKingPlayer !== null
    };

    setMoveHistory([...moveHistory, newMoveRecord]);
    setBoardHistory([...boardHistory, newBoard]);
    setHistoryPosition(boardHistory.length);
    setLastMove(newMoveRecord);
    
    setBoardState(newBoard);
    
    setTimeout(() => {
      // Check for king capture victory first
      const kingVictory = checkKingCaptureVictory(newBoard);
      if (kingVictory !== null) {
        setWinner(kingVictory);
        setGameStatus('completed');
        setIsSimulating(false);
        return;
      }
      
      // Then check territory victory
      const newTerritories = calculateAllTerritories(newBoard, territories);
      const victoryPlayer = checkVictoryCondition(newTerritories);
      
      if (victoryPlayer !== null) {
        setWinner(victoryPlayer);
        setGameStatus('completed');
        setIsSimulating(false);
      }
    }, 100);
    
    let nextPlayer = (activePlayer + 1) % 4;
    let searchAttempts = 0;
    while (newEliminated.includes(nextPlayer) && searchAttempts < 4) {
      nextPlayer = (nextPlayer + 1) % 4;
      searchAttempts++;
    }
    
    if (searchAttempts >= 4) {
      setGameStatus('completed');
      return;
    }
    
    setCurrentTurn(nextPlayer);
  };

  const handleStartSimulation = () => {
    setIsSimulating(true);
  };

  const handlePauseSimulation = () => {
    setIsSimulating(false);
  };

  const handleResetGame = () => {
    const initialBoard = initializeBoard();
    setBoardState(initialBoard);
    setBoardHistory([initialBoard]);
    setHistoryPosition(0);
    setCurrentTurn(0);
    setMoveHistory([]);
    setEliminatedPlayers([]);
    setGameStatus('active');
    setIsSimulating(false);
    setSelectedSquare(null);
    setValidMoves([]);
    setWinner(null);
    setTerritories({});
    setTerritoryPercentages({ 0: 0, 1: 0, 2: 0, 3: 0 });
    setLastMove(null);
    setGameStarted(false);
    setHiddenValleyTracking({});
    setQueenPromotionAlert(null);
  };

  const handleSquareClick = (row, col) => {
    if (isViewingHistory) return; // Can't move while viewing history
    if (!humanPlayers.includes(currentTurn) || eliminatedPlayers.includes(currentTurn)) {
      return;
    }
    
    const piece = boardState[`${row},${col}`];
    
    if (selectedSquare && validMoves.length > 0) {
      const isValidMove = validMoves.some(m => m.row === row && m.col === col);
      if (isValidMove) {
        const { board: newBoard, captured, capturedKingPlayer } = makeMove(
          boardState,
          selectedSquare.row,
          selectedSquare.col,
          row,
          col,
          lastMove
        );
        
        // Play move sound
        if (moveSound.current) moveSound.current();
        
        let newEliminated = [...eliminatedPlayers];
        if (capturedKingPlayer !== null) {
          newEliminated.push(capturedKingPlayer);
          setEliminatedPlayers(newEliminated);
        }
        
        const movedPiece = boardState[`${selectedSquare.row},${selectedSquare.col}`];
        const newMoveRecord = {
          player: currentTurn,
          piece: movedPiece.type,
          from: selectedSquare,
          to: { row, col },
          captured: piece,
          capturedKing: capturedKingPlayer !== null
        };

        setMoveHistory([...moveHistory, newMoveRecord]);
        setBoardHistory([...boardHistory, newBoard]);
        setHistoryPosition(boardHistory.length);
        setLastMove(newMoveRecord);
        
        setBoardState(newBoard);
        setSelectedSquare(null);
        setValidMoves([]);
        
        let nextPlayer = (currentTurn + 1) % 4;
        let attempts = 0;
        while (newEliminated.includes(nextPlayer) && attempts < 4) {
          nextPlayer = (nextPlayer + 1) % 4;
          attempts++;
        }
        
        if (attempts >= 4) {
          setGameStatus('completed');
          return;
        }
        
        setCurrentTurn(nextPlayer);
        
        // Check for king capture victory first
        const kingVictory = checkKingCaptureVictory(newBoard);
        if (kingVictory !== null) {
          setWinner(kingVictory);
          setGameStatus('completed');
          return;
        }
        
        // Then check territory victory
        const newTerritories = calculateAllTerritories(newBoard, territories);
        const victoryPlayer = checkVictoryCondition(newTerritories);
        if (victoryPlayer !== null) {
          setWinner(victoryPlayer);
          setGameStatus('completed');
        }
      } else if (piece && piece.owner === currentTurn && piece.alive) {
        setSelectedSquare({ row, col });
        setValidMoves(getValidMoves(boardState, row, col, piece, lastMove));
      } else {
        setSelectedSquare(null);
        setValidMoves([]);
      }
    } else if (piece && piece.owner === currentTurn && !eliminatedPlayers.includes(currentTurn) && piece.alive) {
      setSelectedSquare({ row, col });
      setValidMoves(getValidMoves(boardState, row, col, piece, lastMove));
    }
  };

  useEffect(() => {
    if (isSimulating && gameStatus === 'active' && !isAIThinking) {
      const timer = setTimeout(() => {
        executeAIMove();
      }, 100);
      
      return () => clearTimeout(timer);
    }
  }, [isSimulating, currentTurn, boardState, gameStatus, isAIThinking, eliminatedPlayers]);

  if (!gameStarted) {
    return <GameSetup onStartGame={handleGameSetup} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
            Donut Chess
          </h1>
          <p className="text-gray-600 text-lg">
            4-Player Chess Variant • Capturable Kings • Territory Control Victory
          </p>
        </motion.div>

        <TerritoryBar territoryPercentages={territoryPercentages} playerColors={playerColors} />

        <HiddenValleyRules hiddenValleyTracking={hiddenValleyTracking} playerColors={playerColors} />

        {isViewingHistory && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Alert className="mb-6 bg-blue-50 border-blue-200">
              <AlertDescription className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <ChevronLeft className="h-5 w-5 text-blue-600" />
                  <span className="font-semibold text-blue-900">
                    Viewing Move {historyPosition} of {boardHistory.length - 1}
                  </span>
                  <ChevronRight className="h-5 w-5 text-blue-600" />
                </div>
                <span className="text-sm text-blue-700">Use ← → arrow keys to navigate</span>
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        <AnimatePresence>
          {queenPromotionAlert && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <Alert className="mb-6 bg-gradient-to-r from-purple-50 to-pink-100 border-2 border-purple-400">
                <Sparkles className="h-5 w-5 text-purple-600" />
                <AlertDescription className="text-lg font-semibold text-gray-900">
                  {queenPromotionAlert.valleyName} Hidden Valley Promotion! Player {queenPromotionAlert.player + 1} has summoned a Queen!
                </AlertDescription>
              </Alert>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {gameStatus === 'completed' && winner !== null && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <Alert className="mb-6 bg-gradient-to-r from-yellow-50 to-yellow-100 border-2 border-yellow-400">
                <Crown className="h-5 w-5 text-yellow-600" />
                <AlertDescription className="text-lg font-semibold text-gray-900">
                  Victory! Player {winner + 1} wins {territoryPercentages[winner] >= 75 ? `with ${territoryPercentages[winner].toFixed(1)}% territory control` : 'by capturing all enemy kings'}!
                </AlertDescription>
              </Alert>
            </motion.div>
          )}
        </AnimatePresence>

        {isAIThinking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mb-6"
          >
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription className="flex items-center gap-3">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                <span>Player {currentTurn + 1} is thinking...</span>
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl shadow-2xl p-4"
            >
              <GameBoard
                boardState={displayBoard}
                onSquareClick={handleSquareClick}
                selectedSquare={isViewingHistory ? null : selectedSquare}
                validMoves={isViewingHistory ? [] : validMoves}
                viewPerspective={viewPerspective}
                territories={territories}
                playerColors={playerColors}
                hiddenValleyTracking={hiddenValleyTracking}
                lastMove={lastMove}
              />
            </motion.div>
            
            <MoveHistory moveHistory={moveHistory} playerColors={playerColors} />
          </div>

          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <ScoreBoard
                territoryPercentages={territoryPercentages}
                currentTurn={currentTurn}
                eliminatedPlayers={eliminatedPlayers}
                gameStatus={gameStatus}
                playerColors={playerColors}
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <GameControls
                isSimulating={isSimulating}
                onStartSimulation={handleStartSimulation}
                onPauseSimulation={handlePauseSimulation}
                onResetGame={handleResetGame}
                viewPerspective={viewPerspective}
                onViewChange={setViewPerspective}
                onStepMove={executeAIMove}
                moveCount={moveHistory.length}
                humanPlayers={humanPlayers}
              />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}